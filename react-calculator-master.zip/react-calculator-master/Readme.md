# react-calculator

This is a simple Calculator written using Node and React. It was written as a guide to following this [tutorial]().

## Getting Started

To try out the project on your development machine, just clone the project, navigate into the folder in which the project was cloned and run the following command
```
npm install && npm start
```

### Prerequisites

This app requires the [Node](https://nodejs.org/) installed on your development machine.

## Author

* **Azeez Olaniran**

## License

This project is licensed under the MIT License
